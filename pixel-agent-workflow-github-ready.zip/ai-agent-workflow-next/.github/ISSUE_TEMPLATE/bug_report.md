---
name: Bug report
about: Report a scene, sprite, workflow, or console issue
labels: bug
---

## What happened?

## Steps to reproduce

## Expected behavior

## Screenshots / recordings

## Environment
- OS:
- Browser:
- Node version:
