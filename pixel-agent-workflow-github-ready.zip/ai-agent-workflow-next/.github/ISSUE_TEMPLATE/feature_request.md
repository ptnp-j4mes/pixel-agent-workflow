---
name: Feature request
about: Suggest a new pixel scene, sprite, model, or workflow feature
labels: enhancement
---

## Feature idea

## Why it helps

## Suggested UI / behavior

## Notes
